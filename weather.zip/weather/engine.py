import torch.optim as optim
from metrics import *
#from models.ViT import model
#from models.Swim_Transformer import SwimTransformer
from models.init import model_select,ModelSize

class trainer():
    def __init__(self, device, out_steps, spa_highth, spa_width, transform, lrate, decay, wdecay):
        model = model_select('TransMLP')
        ModelSize(model)
        #self.model = torch.nn.DataParallel(model.to(device), device_ids=[0,1])  # 声明所有可用设备
        self.model = model.to(device)
        self.optimizer = optim.Adam(self.model.parameters(), lr=lrate, weight_decay=wdecay)
        self.scheduler = optim.lr_scheduler.ExponentialLR(self.optimizer, decay)
        self.loss = masked_mae
        self.transform = transform
        self.clip = 5
        self.out_steps = out_steps

    def train(self, input, real_val):
        self.model.train()
        self.optimizer.zero_grad()
        output = self.model(input)# [b,l,h,w]
        real = real_val
        predict = output

        loss = self.loss(predict, real)
        loss.backward()
        if self.clip is not None:
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.clip)
        self.optimizer.step()
        mae = masked_mae(predict, real).item()
        mape = masked_mape(predict, real).item()
        rmse = masked_rmse(predict, real).item()
        return loss.item(), mae, mape, rmse

    def eval(self, input, real_val):
        self.model.eval()
        output = self.model(input)
        for i in range(self.out_steps):
            real_val[:, i, :, :] = self.transform[i].inverse_transform(real_val[:, i, :, :])
            output[:, i, :, :] = self.transform[i].inverse_transform(output[:, i, :, :])
        real = real_val
        predict = output
        loss = self.loss(predict, real)
        mae = masked_mae(predict, real).item()
        mape = masked_mape(predict, real).item()
        rmse = masked_rmse(predict, real).item()
        return loss.item(), mae, mape, rmse
'''
x = torch.rand((4,6,128,256)).to('cuda')
y = torch.rand((4,6,128,256)).to('cuda')
z = trainer('cuda',6,128,256,None,0.1,0.1,0.2)
b,x,c,v = z.train(x,y)
print(b,x,c,v)
'''
#model = model_select('TransMLP')
#ModelSize(model)