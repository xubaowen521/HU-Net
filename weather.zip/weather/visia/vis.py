import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import cartopy.crs as ccrs
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER

mpl.rcParams["font.size"] = 13

# %%
# ----------------绘制大地图------------------------------
def map_plot(fig, ax, lat, lon, data, is_mask, is_province_boundary, title):
    # 绘制填色图
    cf = ax.contourf(lon, lat, data, cmap=plt.cm.jet, levels=np.linspace(-12, 30, 43), transform=ccrs.PlateCarree())

    # 添加海岸线
    ax.coastlines()

    # 设置标题
    ax.set_title(title)

    # 添加经纬度格网
    gl = ax.gridlines(draw_labels=True, linestyle=":", linewidth=0.1, x_inline=False, y_inline=False, color='k')
    gl.top_labels = False  # 关闭上部经纬标签
    gl.right_labels = False  # 关闭右边经纬标签
    gl.rotate_labels = None  # 关闭兰伯特经纬标签旋转
    gl.xformatter = LONGITUDE_FORMATTER  # 使横坐标转化为经纬度格式
    gl.yformatter = LATITUDE_FORMATTER

    # 添加coloarbar
    fig.colorbar(cf, ax=ax, shrink=0.9, extendfrac='auto', extendrect=True, location='bottom', fraction=0.05, pad=0.08)

import pickle
#with open('E:\\cloud_cover\\11\\v10_val.pkl', 'rb') as f:
#    data = pickle.load(f)
data = np.load('C:\\pythonProject\\weather\\visia\\SwinTransUNet_prediction_results.npz')
with open('C:\\pythonProject\\weather\\visia\\position_info.pkl', 'rb') as f:
    pos_data = pickle.load(f)
t = data['prediction']
#t = data['ground_truth']
#t = data['x']
print(t.shape)
lon = pos_data['lon']
lat = pos_data['lat']
print(lon.shape)
print(lat.shape)
for i in range(6):
    data = t[0, i, :, :]
    proj = ccrs.PlateCarree()
    fig = plt.figure(figsize=(6, 6))
    # 调入参数，画图
    ax1 = fig.add_subplot(1, 1, 1, projection=proj)
    map_plot(fig, ax1, lat, lon, data, True, True, ' ')  # 绘制大地图
    plt.savefig('tpre' + str(i) + '.jpg')
#data = t[1000,2,:,:]    #.reshape(-1,12,128, 256)[0,2,:,:]
##data = t[2,:,:]
#proj = ccrs.PlateCarree()
#fig = plt.figure(figsize=(6, 6))
## 调入参数，画图
#ax1 = fig.add_subplot(1, 1, 1, projection=proj)
#map_plot(fig, ax1,  lat,lon, data, True, True, ' ')  # 绘制大地图
#plt.savefig('t' + str(0) + '.jpg')