from dataset import build_loader
import torch
import numpy as np
import argparse
#from engine import trainer
from metrics import metric
import os
import time
from models.init import model_select,ModelSize
parser = argparse.ArgumentParser()
###data
parser.add_argument('--dataset_dir', type=str, default='/home/xbw/total_precipitation', help='data path')
parser.add_argument('--test', type=bool, default=True, help='whether to test')
parser.add_argument('--batch_size', type=int, default=16, help='batch size')
parser.add_argument('--save', type=str, default='/home/xbw/weather_beach/tp',help='save path')
parser.add_argument('--model', type=str, default='HUNet', help='model type')
parser.add_argument('--decay', type=float, default=0.92, help='decay rate of learning rate ')
parser.add_argument('--learning_rate', type=float, default=0.001, help='learning rate')
parser.add_argument('--weight_decay', type=float, default=0.0001, help='weight decay rate')
parser.add_argument('--spatial_highth', type=int, default=128, help='inputs dimension')
parser.add_argument('--spatial_width', type=int, default=256, help='number of nodes;jinan 561,xian:792')
parser.add_argument('--seq_length', type=int, default=6, help='inputs dimension')

args = parser.parse_args()

def main():
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    dataset, dataloader = build_loader(args)
    Scaler = dataset['scaler']

    #engines = trainer(device, args.seq_length, args.spatial_highth, args.spatial_width, Scaler,
    #                  args.learning_rate, args.decay, args.weight_decay)

    params_path = args.save + "/" + args.model

    # testing
    model = model_select('TransMLP').to(device)
    #model.load_state_dict(torch.load(
    #    params_path + "/" + args.model + "_epoch_" + str("best") + ".pth"))
    model.load_state_dict(torch.load("/home/xbw/weather_beach/tp/HUNet/HUNet_epoch_30_0.85.pth"))
    ModelSize(model)
    print("Loading finished")
    model.eval()
    outputs = []
    realy = []
    t_rep1 = time.time()
    outputs1 = []
    realy1 = []
    for iter, (x, y) in enumerate(dataloader['test_loader']):
        testx = torch.Tensor(x).to(device)
        realy.append(y)
        with torch.no_grad():
            preds = model(testx).cpu()  #engines.
        outputs.append(preds)
    t_no = time.time() - t_rep1
    print(f"No Re-parameter Inference Time: {t_no}")

    #for module in model.modules():
    #    if hasattr(module, '_switch_to_deploy'):
    #        module._switch_to_deploy()
    #t_rep = time.time()
    #for iter, (x, y) in enumerate(dataloader['test_loader']):
    #    testx = torch.Tensor(x).to(device)
    #    realy1.append(y)
    #    with torch.no_grad():
    #        preds = model(testx).cpu()  #engines.
    #    outputs1.append(preds)
    #t_with = time.time()-t_rep
    #print(f"Inference Time: {t_with}")
    yhat = torch.cat(outputs, dim=0)
    realy = torch.cat(realy,dim=0)

    txt_path = args.save + "/" + args.model + "/" + "test" + "metrics"
    file = open(txt_path, 'w')
    amae = []
    amape = []
    armse = []
    prediction = yhat
    for i in range(args.seq_length):
        prediction[:, i, :, :] = Scaler[i].inverse_transform(prediction[:, i, :, :])
        realy[:, i, :, :] = Scaler[i].inverse_transform(realy[:, i, :, :])

        pred = prediction[:, i, :, :]
        # pred = scaler.inverse_transform(yhat[:,:,i])
        # prediction.append(pred)
        real = realy[:, i, :, :]
        metrics = metric(pred, real)
        log = 'Evaluate best model on test data for horizon {:d}, Test MAE: {:.4f}, Test MAPE: {:.4f}, Test RMSE: {:.4f}'
        print(log.format(i + 1, metrics[0], metrics[1], metrics[2]))
        amae.append(metrics[0])
        amape.append(metrics[1])
        armse.append(metrics[2])
        file.write(str(i + 1) + ':' + 'MAE' + ' ' + str(metrics[0]*10000) + 'MAPE' + ' ' + str(metrics[1]) + 'RMSE' +
               ' ' + str(metrics[2]*10000) + '\n')
    #file.write("Inference Time: No Re-parameter/ With Re-parameter" + ' ' + str(t_no) + '/' + str(t_with))
    file.write("Average MAE/MAPE/RMSE" + ' ' + str(np.mean(amae)*10000) + '/' +
               str(np.mean(amape)) + '/' + str(np.mean(armse)*10000))
    file.close()
    log = 'On average over 6 horizons, Test MAE: {:.4f}, Test MAPE: {:.4f}, Test RMSE: {:.4f}'
    print(log.format(np.mean(amae)*10000, np.mean(amape), np.mean(armse)*10000))
    prediction_path = params_path + "/" + args.model + "_prediction_results"
    ground_truth = realy[:1000].cpu().detach().numpy()
    prediction = prediction[:1000].cpu().detach().numpy()

    np.savez_compressed(
        os.path.normpath(prediction_path),
        prediction=prediction,
        ground_truth=ground_truth
    )

if __name__ == "__main__":
    t1 = time.time()
    main()
    t2 = time.time()
    print("Total time spent: {:.4f}".format(t2 - t1))