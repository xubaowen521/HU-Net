import numpy as np
import os
import pickle
import torch
from torch.utils.data import Dataset
import torch.distributed as dist


class StandardScaler:
    """
    Standard the input
    """

    def __init__(self, mean, std):
        self.mean = mean
        self.std = std

    def transform(self, data):
        return (data - self.mean) / self.std

    def inverse_transform(self, data):
        return (data * self.std) + self.mean



def load_dataset(dataset_dir,args):

    with open(dataset_dir + '/{}.pkl'.format('trn_x'), 'rb') as f:
        data = pickle.load(f)
    data_x = data['data']
    train_numpy = data_x
    horizon_len = data_x.shape[1]

    scaler = [StandardScaler(mean=train_numpy[:, i, :, :].mean(), std=train_numpy[:, i, :, :].std()) for i in
              range(horizon_len)]
    if args.test:
        data = {}
        test_set = MyDataset(dataset_dir, mode='test', scaler=scaler)
        data['test_dataset'] = test_set
        data['scaler'] = scaler
        return data
    train_set = MyDataset(dataset_dir, mode='trn', scaler=scaler)
    validation_set = MyDataset(dataset_dir, mode='val', scaler=scaler)

    data = {}
    data['train_dataset'] = train_set
    data['val_dataset'] = validation_set
    data['scaler'] = scaler

    return data


class MyDataset(Dataset):
    """IRDataset dataset."""

    def __init__(self, dataset_dir, mode, scaler):
        self.file = dataset_dir
        print('loading data of {} set...'.format(mode))

        with open(dataset_dir + '/{}_x.pkl'.format(mode), 'rb') as f:
            data_x = pickle.load(f)
        data_x = data_x['data']
        with open(dataset_dir + '/{}_y.pkl'.format(mode), 'rb') as f:
            data_y = pickle.load(f)
        data_y = data_y['data']
        self.x = data_x
        self.y = data_y
        horizon_len = data_x.shape[1]

        if scaler != None:
            self.scaler = scaler
            for i in range(horizon_len):
                self.x[:, i, :, :] = scaler[i].transform(self.x[:, i, :, :])
                self.y[:, i, :, :] = scaler[i].transform(self.y[:, i, :, :])

    def __len__(self):
        return self.x.shape[0]

    def __getitem__(self, idx):
        data = self.x[idx]
        labels = self.y[idx]

        return data, labels

def build_loader(args):
    dataset = load_dataset(args.dataset_dir,args)
    if args.test:
        dataset_test = dataset['test_dataset']
        data_loader_test = torch.utils.data.DataLoader(
            dataset_test,
            batch_size=args.batch_size,
            shuffle=False,
            num_workers=4,
            pin_memory=True,
            drop_last=False
        )
        dataloader = {}
        dataloader['test_loader'] = data_loader_test
        return dataset,dataloader

    dataset_train = dataset['train_dataset']
    dataset_val = dataset['val_dataset']

    '''
    num_tasks = dist.get_world_size()
    global_rank = dist.get_rank()

    sampler_train = torch.utils.data.DistributedSampler(
            dataset_train, num_replicas=num_tasks, rank=global_rank, shuffle=True
        )
    '''
    data_loader_train = torch.utils.data.DataLoader(
        dataset_train,                      # sampler=sampler_train,
        batch_size=args.batch_size,
        shuffle= True,
        num_workers=2,
        pin_memory=True,
        drop_last=True,
    )

    data_loader_val = torch.utils.data.DataLoader(
            dataset_val,
            batch_size=args.batch_size,
            shuffle=False,
            num_workers=2,
            pin_memory=True,
            drop_last=False
        )

    dataloader = {}
    dataloader['train_loader'] = data_loader_train
    dataloader['val_loader'] = data_loader_val


    return dataset, dataloader