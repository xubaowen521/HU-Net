import numpy as np
import matplotlib.pyplot as plt

#data1 = np.load('E:\\VAE实验结果\\PEMS03\\AGCRN_test_prediction_results.npz')

#data2 = np.load('C:\\pythonProject\\CO\\GRU_d12\\test_prediction_results.npz')
data = np.load('/home/xbw/weather_beach/t2m/TransMLP_RepVGG/TransMLP_RepVGG_prediction_results.npz')

data1 = np.load('/home/xbw/weather_beach/t2m/vit_16/vit_16_prediction_results.npz')

data2 = np.load('/home/xbw/weather_beach/t2m/swim_t/swim_t_prediction_results.npz')
data3 = np.load('/home/xbw/weather_beach/t2m/unet/unet_prediction_results.npz')
data4 = np.load('/home/xbw/weather_beach/t2m/SwinTransUNet/SwinTransUNet_prediction_results.npz')

pred = data['prediction']   #(3548, N,12)
label = data['ground_truth']
pred1 = data1['prediction']
pred2 = data2['prediction']
pred3 = data3['prediction']
pred4 = data4['prediction']
print(pred.shape)
#pred3 = data3['prediction']
plt.figure(figsize=(15,5))
#plt.figure(figsize=(10,4))
#plt.title('PEMSD7; one day; 10-th node; first time step',x=0.8,y=0.9)
#plt.title('PEMSD3; one day',x=0.9,y=0.9)
#pred[-192 :-96, 0,:] = label[-192:-96, 0,:]
plt.xlabel("Time (3h)", fontsize=10)
plt.ylabel("Temperature", fontsize=10)    # Temperature (K)  Humidity (%)    component of wind ($ms^{-1}$) Cloud Cover (%)
plt.plot(label[ :700, -1, 30, 10],linewidth=0.8)
plt.plot(pred[  :700, -1, 30, 10],linewidth=0.8)
plt.plot(pred1[ :700, -1, 30, 10],linewidth=0.8)
plt.plot(pred2[ :700, -1, 30, 10],linewidth=0.8)
plt.plot(pred3[ :700, -1, 30, 10],linewidth=0.8)
plt.plot(pred4[ :700, -1, 30, 10],linewidth=0.8)

#print(label[:,0,-1].shape)
##plt.plot(pred3[ :144, 10,-1])
plt.legend(["Ground Truth","Prediction(Ours)","Prediction(ViT)", "Prediction(Swin_T)", "Prediction(U-Net)", "Prediction(Swin_UNet)"], loc="upper left", fontsize=9)
plt.show()
