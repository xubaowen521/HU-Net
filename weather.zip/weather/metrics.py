import torch


def masked_mae(y_pred, y_true):
    mask = (y_true != 0).float()
    mask /= mask.mean()
    loss = torch.abs(y_pred - y_true)
    loss = loss * mask
    loss[loss != loss] = 0
    return loss.mean()

def masked_mse(y_pred, y_true):
    mask = (y_true != 0).float()
    mask /= mask.mean()
    loss = torch.square(y_pred - y_true)
    loss = loss * mask
    loss[loss != loss] = 0
    return loss.mean()

def masked_mape(y_pred, y_true):
    mask = (y_true != 0).float()
    mask /= mask.mean()
    loss = torch.abs(y_pred - y_true)/y_true
    loss = loss * mask
    loss[loss != loss] = 0
    return loss.abs().mean()

def masked_rmse(preds, labels):
    return torch.sqrt(masked_mse(preds,labels))

def metric(pred, real):
    mae = masked_mae(pred,real).item()
    mape = masked_mape(pred,real).item()
    rmse = masked_rmse(pred,real).item()
    return mae,mape,rmse
'''
x = torch.rand((16,6,128,256))
y = torch.rand((16,6,128,256))
z = masked_mse(x,y)
print(z.item())
'''




