from torchvision import models
import torch.nn as nn

class ResNet50(nn.Module):
    def __init__(self,high,width):
        super(ResNet50, self).__init__()
        net = models.resnet50(pretrained = False)
        net.conv1 = nn.Conv2d(6, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False)
        self.net = nn.Sequential(*list(net.children())[:-3])
        self.high = nn.Linear(8, high)
        self.width = nn.Linear(16, width)
        self.last_conv_1 = nn.Conv2d(1024, 512, kernel_size=1)
        self.last_conv_2 = nn.Conv2d(512, 6, kernel_size=1)

    def forward(self,x):
        x = self.net(x)
        x = self.width(x).transpose(-2,-1)
        x = self.high(x).transpose(-2,-1)
        x = self.last_conv_1(x)
        x = self.last_conv_2(x)
        return  x

class ResNet101(nn.Module):
    def __init__(self, high, width):
        super(ResNet101, self).__init__()
        net = models.resnet101(pretrained = False)
        net.conv1 = nn.Conv2d(6, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False)
        self.net = nn.Sequential(*list(net.children())[:-3])
        self.high = nn.Linear(8, high)
        self.width = nn.Linear(16, width)
        self.last_conv_1 = nn.Conv2d(1024, 512, kernel_size=1)
        self.last_conv_2 = nn.Conv2d(512, 6, kernel_size=1)

    def forward(self,x):
        x = self.net(x)
        x = self.width(x).transpose(-2,-1)
        x = self.high(x).transpose(-2,-1)
        x = self.last_conv_1(x)
        x = self.last_conv_2(x)
        return  x

if __name__ == "__main__":
    import torch
    net = ResNet50(128,256)
    x = torch.rand((1,6,128,256))
    y = net(x)
    print(y.shape)
