import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
import math
from models.BiFuse import Fusion_block
###             repvgg


def _conv_bn(input_channel, output_channel, kernel_size=3, padding=1, stride=1, groups=1):
    res = nn.Sequential()
    res.add_module('conv', nn.Conv2d(in_channels=input_channel, out_channels=output_channel, kernel_size=kernel_size,
                                     padding=padding, padding_mode='zeros', stride=stride, groups=groups, bias=False))
    res.add_module('bn', nn.BatchNorm2d(output_channel))
    return res


class SEBlock(nn.Module):
    def __init__(self, in_channels, reduction_ratio=16):
        super(SEBlock, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc1 = nn.Linear(in_channels, in_channels // reduction_ratio)
        self.fc2 = nn.Linear(in_channels // reduction_ratio, in_channels)

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = F.relu(self.fc1(y))
        y = self.fc2(y).sigmoid().view(b, c, 1, 1)
        return x * y

class RepBlock(nn.Module):
    def __init__(self, input_channel, output_channel, kernel_size=3, groups=1, stride=1, deploy=False, use_se=True):
        super().__init__()
        self.use_se = use_se
        self.input_channel = input_channel
        self.output_channel = output_channel
        self.deploy = deploy
        self.kernel_size = kernel_size
        self.padding = kernel_size // 2
        self.groups = groups
        self.activation = nn.ReLU()

        # make sure kernel_size=3 padding=1
        assert self.kernel_size == 3
        assert self.padding == 1
        if (not self.deploy):
            self.brb_3x3 = _conv_bn(input_channel, output_channel, kernel_size=self.kernel_size, padding=self.padding,
                                    groups=groups)
            self.brb_1x1 = _conv_bn(input_channel, output_channel, kernel_size=1, padding=0, groups=groups)
            self.brb_identity = nn.BatchNorm2d(
                self.input_channel) if self.input_channel == self.output_channel else None
        else:
            self.brb_rep = nn.Conv2d(in_channels=input_channel, out_channels=output_channel,
                                     kernel_size=self.kernel_size, padding=self.padding, padding_mode='zeros',
                                     stride=stride, bias=True)

        if (self.use_se):
            self.se = SEBlock(output_channel, 4)
        else:
            self.se = nn.Identity()

    def forward(self, inputs):
        if (self.deploy):
            return self.activation(self.se(self.brb_rep(inputs)))

        if (self.brb_identity == None):
            identity_out = 0
        else:
            identity_out = self.brb_identity(inputs)

        return self.activation(self.se(self.brb_1x1(inputs) + self.brb_3x3(inputs) + identity_out))

    def _switch_to_deploy(self):
        self.deploy = True
        kernel, bias = self._get_equivalent_kernel_bias()
        self.brb_rep = nn.Conv2d(in_channels=self.brb_3x3.conv.in_channels, out_channels=self.brb_3x3.conv.out_channels,
                                 kernel_size=self.brb_3x3.conv.kernel_size, padding=self.brb_3x3.conv.padding,
                                 padding_mode=self.brb_3x3.conv.padding_mode, stride=self.brb_3x3.conv.stride,
                                 groups=self.brb_3x3.conv.groups, bias=True)
        self.brb_rep.weight.data = kernel
        self.brb_rep.bias.data = bias
        # 消除梯度更新
        for para in self.parameters():
            para.detach_()
        # 删除没用的分支
        self.__delattr__('brb_3x3')
        self.__delattr__('brb_1x1')
        self.__delattr__('brb_identity')

    # 将1x1的卷积变成3x3的卷积参数
    def _pad_1x1_kernel(self, kernel):
        if (kernel is None):
            return 0
        else:
            return F.pad(kernel, [1] * 4)

    # 将identity，1x1,3x3的卷积融合到一起，变成一个3x3卷积的参数
    def _get_equivalent_kernel_bias(self):
        brb_3x3_weight, brb_3x3_bias = self._fuse_conv_bn(self.brb_3x3)
        brb_1x1_weight, brb_1x1_bias = self._fuse_conv_bn(self.brb_1x1)
        brb_id_weight, brb_id_bias = self._fuse_conv_bn(self.brb_identity)
        return brb_3x3_weight + self._pad_1x1_kernel(
            brb_1x1_weight) + brb_id_weight, brb_3x3_bias + brb_1x1_bias + brb_id_bias

    ### 将卷积和BN的参数融合到一起
    def _fuse_conv_bn(self, branch):
        if (branch is None):
            return 0, 0
        elif (isinstance(branch, nn.Sequential)):
            kernel = branch.conv.weight
            running_mean = branch.bn.running_mean
            running_var = branch.bn.running_var
            gamma = branch.bn.weight
            beta = branch.bn.bias
            eps = branch.bn.eps
        else:
            assert isinstance(branch, nn.BatchNorm2d)
            if not hasattr(self, 'id_tensor'):
                input_dim = self.input_channel // self.groups
                kernel_value = np.zeros((self.input_channel, input_dim, 3, 3), dtype=np.float32)
                for i in range(self.input_channel):
                    kernel_value[i, i % input_dim, 1, 1] = 1
                self.id_tensor = torch.from_numpy(kernel_value).to(branch.weight.device)
            kernel = self.id_tensor
            running_mean = branch.running_mean
            running_var = branch.running_var
            gamma = branch.weight
            beta = branch.bias
            eps = branch.eps

        std = (running_var + eps).sqrt()
        t = gamma / std
        t = t.view(-1, 1, 1, 1)
        return kernel * t, beta - running_mean * gamma / std

'''
import time

x = torch.ones(10,96,128,256).to('cuda')
model = RepBlock(96,96).to('cuda')
model.eval()
t1 = time.time()
y = model(x)
print('111',y.shape,time.time()-t1)
t2 = time.time()
for module in model.modules():
    if hasattr(module, '_switch_to_deploy'):
        module._switch_to_deploy()
#model._switch_to_deploy()
new_y = model(x)
t4 = time.time()
#print(y,new_y)
print(F.mse_loss(new_y,y),t4-t2)
'''
###


class GlobalPerceptron(nn.Module):

    def __init__(self, input_channels, out_channels, internal_neurons):
        super(GlobalPerceptron, self).__init__()
        self.fc1 = nn.Conv2d(in_channels=out_channels, out_channels=internal_neurons, kernel_size=1, stride=1, bias=True)
        self.fc2 = nn.Conv2d(in_channels=internal_neurons, out_channels=out_channels, kernel_size=1, stride=1, bias=True)
        self.input_channels = out_channels
        self.chann = nn.Conv2d(input_channels,out_channels,kernel_size=1)
        self._init_weights()

    def _init_weights(self):
        nn.init.xavier_uniform_(self.fc1.weight)
        nn.init.xavier_uniform_(self.fc2.weight)
        nn.init.normal_(self.fc1.bias, std=1e-6)
        nn.init.normal_(self.fc2.bias, std=1e-6)
    def forward(self, inputs):
        inputs = self.chann(inputs)
        x = F.adaptive_avg_pool2d(inputs, output_size=(1, 1))
        x = self.fc1(x)
        x = F.relu(x, inplace=True)
        x = self.fc2(x)
        x = F.sigmoid(x)
        x = x.view(-1, self.input_channels, 1, 1)
        return x

class RepMLPBlock(nn.Module):

    def __init__(self, input_channel, output_channel, kernel_size=3, groups=1, stride=1, deploy=False, use_se=True,
                 globalperceptron_reduce=4):
        super().__init__()
        self.repblock = RepBlock(input_channel, output_channel, kernel_size=kernel_size, groups=groups,
                                 stride=stride, deploy=deploy, use_se=use_se)
        self.gp = GlobalPerceptron(input_channels=input_channel, out_channels= output_channel,internal_neurons=input_channel // globalperceptron_reduce)


    def forward(self, inputs):
        global_vec = self.gp(inputs)
        out = self.repblock(inputs)
        out = out * global_vec
        return out

class Mlp(nn.Module):
    def __init__(
        self,
        in_features, hidden_features=None, out_features=None,
        act_layer=nn.GELU, drop=0.0
    ):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop) if drop > 0 else nn.Identity()

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x


class AFNO2D(nn.Module):
    def __init__(self, hidden_size, num_blocks=8, sparsity_threshold=0.01, hard_thresholding_fraction=1, hidden_size_factor=1):
        super().__init__()
        assert hidden_size % num_blocks == 0, f"hidden_size {hidden_size} should be divisble by num_blocks {num_blocks}"

        self.hidden_size = hidden_size
        self.sparsity_threshold = sparsity_threshold
        self.num_blocks = num_blocks
        self.block_size = self.hidden_size // self.num_blocks
        self.hard_thresholding_fraction = hard_thresholding_fraction
        self.hidden_size_factor = hidden_size_factor
        self.scale = 0.02

        self.w1 = nn.Parameter(self.scale * torch.randn(2, self.num_blocks, self.block_size, self.block_size * self.hidden_size_factor))
        self.b1 = nn.Parameter(self.scale * torch.randn(2, self.num_blocks, self.block_size * self.hidden_size_factor))
        self.w2 = nn.Parameter(self.scale * torch.randn(2, self.num_blocks, self.block_size * self.hidden_size_factor, self.block_size))
        self.b2 = nn.Parameter(self.scale * torch.randn(2, self.num_blocks, self.block_size))

    def forward(self, x):
        bias = x

        dtype = x.dtype
        x = x.float()
        B, H, W, C = x.shape
        x = torch.fft.rfft2(x, dim=(1, 2), norm="ortho")
        x = x.reshape(B, H, W // 2 + 1, self.num_blocks, self.block_size)

        o1_real = torch.zeros([B, H, W // 2 + 1, self.num_blocks, self.block_size * self.hidden_size_factor], device=x.device)
        o1_imag = torch.zeros([B, H, W // 2 + 1, self.num_blocks, self.block_size * self.hidden_size_factor], device=x.device)
        o2_real = torch.zeros(x.shape, device=x.device)
        o2_imag = torch.zeros(x.shape, device=x.device)

        total_modes = H // 2 + 1
        kept_modes = int(total_modes * self.hard_thresholding_fraction)

        o1_real[:, total_modes-kept_modes:total_modes+kept_modes, :kept_modes] = F.relu(
            torch.einsum('...bi,bio->...bo', x[:, total_modes-kept_modes:total_modes+kept_modes, :kept_modes].real, self.w1[0]) - \
            torch.einsum('...bi,bio->...bo', x[:, total_modes-kept_modes:total_modes+kept_modes, :kept_modes].imag, self.w1[1]) + \
            self.b1[0]
        )

        o1_imag[:, total_modes-kept_modes:total_modes+kept_modes, :kept_modes] = F.relu(
            torch.einsum('...bi,bio->...bo', x[:, total_modes-kept_modes:total_modes+kept_modes, :kept_modes].imag, self.w1[0]) + \
            torch.einsum('...bi,bio->...bo', x[:, total_modes-kept_modes:total_modes+kept_modes, :kept_modes].real, self.w1[1]) + \
            self.b1[1]
        )

        o2_real[:, total_modes-kept_modes:total_modes+kept_modes, :kept_modes]  = (
            torch.einsum('...bi,bio->...bo', o1_real[:, total_modes-kept_modes:total_modes+kept_modes, :kept_modes], self.w2[0]) - \
            torch.einsum('...bi,bio->...bo', o1_imag[:, total_modes-kept_modes:total_modes+kept_modes, :kept_modes], self.w2[1]) + \
            self.b2[0]
        )

        o2_imag[:, total_modes-kept_modes:total_modes+kept_modes, :kept_modes]  = (
            torch.einsum('...bi,bio->...bo', o1_imag[:, total_modes-kept_modes:total_modes+kept_modes, :kept_modes], self.w2[0]) + \
            torch.einsum('...bi,bio->...bo', o1_real[:, total_modes-kept_modes:total_modes+kept_modes, :kept_modes], self.w2[1]) + \
            self.b2[1]
        )

        x = torch.stack([o2_real, o2_imag], dim=-1)
        x = F.softshrink(x, lambd=self.sparsity_threshold)
        x = torch.view_as_complex(x)
        x = x.reshape(B, H, W // 2 + 1, C)
        x = torch.fft.irfft2(x, s=(H, W), dim=(1,2), norm="ortho")
        x = x.type(dtype)

        return x + bias


class Block(nn.Module):
    def __init__(
            self,
            dim,
            mlp_ratio=4.,
            drop=0.,
            drop_path=0.,
            act_layer=nn.GELU,
            norm_layer=nn.LayerNorm,
            double_skip=True,
            num_blocks=8,
            sparsity_threshold=0.01,
            hard_thresholding_fraction=1.0
        ):
        super().__init__()
        self.norm1 = norm_layer(dim)
        self.filter = AFNO2D(dim, num_blocks, sparsity_threshold, hard_thresholding_fraction)
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)
        self.double_skip = double_skip

    def forward(self, x):
        residual = x
        x = self.norm1(x)
        x = self.filter(x)

        if self.double_skip:
            x = x + residual
            residual = x

        x = self.norm2(x)
        x = self.mlp(x)
        x = x + residual
        return x




####attention
class MLP(nn.Sequential):
    def __init__(self, dim, dim_mul=4):
        inner_dim = dim * dim_mul
        sequence = [
            nn.Linear(dim, inner_dim),
            nn.SiLU(),
            nn.Linear(inner_dim, dim)
        ]
        super().__init__(*sequence)

class TemporalAttention(nn.Module):
    def __init__(
            self, channels, context_channels=None,
            head_dim=32, num_heads=8
    ):
        super().__init__()
        self.channels = channels
        if context_channels is None:
            context_channels = channels
        self.context_channels = context_channels
        self.head_dim = head_dim
        self.num_heads = num_heads
        self.inner_dim = head_dim * num_heads
        self.attn_scale = self.head_dim ** -0.5
        if channels % num_heads:
            raise ValueError("channels must be divisible by num_heads")
        self.KV = nn.Linear(context_channels, self.inner_dim * 2)
        self.Q = nn.Linear(channels, self.inner_dim)
        self.proj = nn.Linear(self.inner_dim, channels)

    def forward(self, x, y=None):
        if y is None:
            y = x

        (K, V) = self.KV(y).chunk(2, dim=-1)
        (B, H, W, C) = K.shape
        shape = (B, H, W, self.num_heads, self.head_dim)
        K = K.reshape(shape)
        V = V.reshape(shape)

        Q = self.Q(x)
        (B,  H, W, C) = Q.shape
        shape = (B, H, W, self.num_heads, self.head_dim)
        Q = Q.reshape(shape)

        K = K.permute((0, 1, 2, 3, 4))  # K^T
        V = V.permute((0, 1, 2, 4, 3))
        Q = Q.permute((0, 1, 2, 4, 3))

        attn = torch.matmul(Q, K) * self.attn_scale
        attn = F.softmax(attn, dim=-1)
        y = torch.matmul(attn, V)
        #y = y.permute((0, 4, 1, 2, 3, 5))
        y = y.reshape((B,  H, W, C))
        y = self.proj(y)
        return y


class TemporalTransformer(nn.Module):
    def __init__(self,
                 channels,
                 mlp_dim_mul=1,
                 **kwargs
                 ):
        super().__init__()
        self.attn1 = TemporalAttention(channels, **kwargs)
        self.attn2 = TemporalAttention(channels, **kwargs)
        self.norm1 = nn.LayerNorm(channels)
        self.norm2 = nn.LayerNorm(channels)
        self.norm3 = nn.LayerNorm(channels)
        self.mlp = MLP(channels, dim_mul=mlp_dim_mul)

    def forward(self, x, y):
        x = self.attn1(self.norm1(x)) + x  # self attention
        x = self.attn2(self.norm2(x), y) + x  # cross attention
        return self.mlp(self.norm3(x)) + x  # feed-forward




def positional_encoding(position, dims, add_dims=()):
    div_term = torch.exp(
        torch.arange(0, dims, 2, device=position.device) *
        (-math.log(10000.0) / dims)
    )
    if position.ndim == 1:
        arg = position[:, None] * div_term[None, :]
    else:
        arg = position[:, :, None] * div_term[None, None, :]

    pos_enc = torch.concat(
        [torch.sin(arg), torch.cos(arg)],
        dim=-1
    )
    if add_dims:
        for dim in add_dims:
            pos_enc = pos_enc.unsqueeze(dim)
    return pos_enc

class PatchEmbed(nn.Module):
    def __init__(self, patch_size=(4,4), in_chans=6, embed_dim=96):
        super().__init__()
        self.patch_size = patch_size
        self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=patch_size, stride=patch_size)

    def forward(self, x):
        x = self.proj(x)
        x = x.permute(0,2,3,1) # convert to BHWC
        return x


class PatchExpand(nn.Module):
    def __init__(self, patch_size=(4,4), out_chans=6, embed_dim=96):
        super().__init__()
        self.patch_size = patch_size
        self.proj = nn.Linear(embed_dim, out_chans*np.prod(patch_size))

    def forward(self, x):
        x = self.proj(x)

        x = rearrange(
            x,
            "b h w (p0 p1 c_out) -> b c_out (h p0) (w p1)",
            p0=self.patch_size[0],
            p1=self.patch_size[1],
            h=x.shape[1],
            w=x.shape[2],
        )
        return x
'''
class FeatureExt(nn.Module):
    def __init__(self, patch_size=(4,4), in_chans= 6, out_chans=6, embed_dim=96):
        super().__init__()
        self.afno1 = Block(embed_dim)
        self.afno2 = Block(embed_dim)
        self.patchembed = PatchEmbed(patch_size,in_chans,embed_dim)
        self.patchexpand = PatchExpand(patch_size,out_chans,embed_dim)
        self.att = TemporalTransformer(embed_dim)
        #self.repmlp = RepMLPBlock(embed_dim,embed_dim)
        #self.featureFusion = Fusion_block(embed_dim,8)

    def forward(self, x):
        x = self.patchembed(x)
        #loacal = x
        x = self.afno1(x)
        x = self.att(x,None)
        x = self.afno2(x)
        #loacal_x = self.repmlp(loacal.permute(0,3,1,2))
        #x = self.featureFusion(x.permute(0,3,1,2),loacal_x).permute(0,2,3,1)
        x = self.patchexpand(x)
        return x

'''

class FeatureExt(nn.Module):
    def __init__(self, patch_size=(4,4), in_chans= 6, out_chans=6, embed_dim=96):
        super().__init__()
        self.afno1 = Block(embed_dim)
        self.afno2 = Block(embed_dim)
        self.patchembed = PatchEmbed(patch_size,in_chans,embed_dim)
        self.patchexpand = PatchExpand(patch_size,out_chans,embed_dim)
        self.att = TemporalTransformer(embed_dim)
        self.repmlp = RepMLPBlock(6,embed_dim)
        self.featureFusion = Fusion_block(embed_dim,8)

    def forward(self, x):
        loacal = x
        x = self.patchembed(x)
        x = self.afno1(x)
        x = self.att(x,None)
        x = self.afno2(x)
        loacal_x = self.repmlp(loacal)
        x = self.patchexpand(x)
        x = self.featureFusion(x,loacal_x)
        return x

if __name__ == "__main__":
    import torch
    import time
    model = FeatureExt(out_chans=96).to('cuda')
    x = torch.rand((1,6,128,256)).to('cuda')
    model.eval()
    t1 = time.time()
    y = model(x)
    print('111', y.shape, time.time() - t1)
    t2 = time.time()
    for module in model.modules():
        if hasattr(module, '_switch_to_deploy'):
            module._switch_to_deploy()
    # model._switch_to_deploy()
    new_y = model(x)
    t4 = time.time()
    # print(y,new_y)
    print(F.mse_loss(new_y, y), t4 - t2)