import torch.nn as nn
import torch
class DoubleConv(nn.Module):
    """(convolution => [BN] => ReLU) * 2"""

    def __init__(self, in_channels, out_channels, mid_channels=None, d=1, k=3, p=1, ):
        super().__init__()
        if not mid_channels:
            mid_channels = out_channels
        self.double_conv = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, kernel_size=k, padding=p, bias=False, dilation=d),
            nn.BatchNorm2d(mid_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_channels, out_channels, kernel_size=k, padding=p, bias=False, dilation=d),
            nn.BatchNorm2d(mid_channels),
            nn.ReLU(inplace=True)
        )
        self._init_weights()

    def _init_weights(self):
        nn.init.kaiming_normal_(self.double_conv[0].weight)
        nn.init.kaiming_normal_(self.double_conv[3].weight)

    def forward(self, x):
        return self.double_conv(x)

class M_conv(nn.Module):
    def __init__(self, channels_in, channels_out):
        super().__init__()
        self.conv1 = DoubleConv(channels_in, channels_out, k=3, p=1, d=1)
        self.conv2 = DoubleConv(channels_in, channels_out, k=3, p=2, d=2)
    def forward(self, img):
        x1 = self.conv1(img)
        x2 = self.conv2(img)
        x_ = torch.cat([x1,x2],dim=1)
        _, _, H, W = x_.shape
        x = x_.flatten(2).transpose(1, 2)
        return x, H, W, x_

'''
image = torch.randn(1, 3, 128, 256)
model = M_conv(3,24)
x = model(image)
print(x.shape)
param_size = 0
for param in model.parameters():
    param_size += param.nelement() * param.element_size()
print(param_size)
'''
