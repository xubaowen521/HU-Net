from models.MLP import LocalMLPNet
from models.SwinTransformer import SwimTransformer
import torch.nn as nn
import numpy as np
import torch
from models.BiFuse import BiFusion_block

class TransMlpEncoder(nn.Module):
    def __init__(self, device):
        super().__init__()
        self.mlp_encoder = LocalMLPNet()
        self.trans_encoder = SwimTransformer()
        channels = ( 96, 192, 384, 768)
        self.fuse = []
        for i in range(len(channels)):
            self.fuse.append(BiFusion_block(channels[i],channels[i],2,channels[i],channels[i]).to(device))


    def forward(self, x):
        trans_features, x_ = self.trans_encoder(x)
        #mlp_features = self.mlp_encoder(x)
        #features = [x + y for x, y in zip(trans_features, mlp_features)]
        #features = []
        #for i in range(len(mlp_features)):
        #    features.append(self.fuse[i](trans_features[i],mlp_features[i]))
        features = trans_features
        return features, x_


if __name__ == '__main__':
    x = torch.randn(1, 6, 128, 256)
    model = TransMlpEncoder()
    out,_ = model(x)
    for i in out:
       print(i.shape)
    param_size = 0
    for param in model.parameters():
        param_size += param.nelement() * param.element_size()
    print(f'{param_size/1024/1024} M')
