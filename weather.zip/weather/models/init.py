from tools import *
from models.Swim_Transformer import SwimTransformer
from models.ViT import ViT_16,ViT_32
from models.resnet import ResNet50,ResNet101
from models.UNet import Unet
from models.swintraunet import SwinTransUNet
from models.u_net import Unet_Modern
from models.ConvLSTM import convlstm
from models.SwinTransformer import Trans
def model_select(a):
    if a == 'ResNet50':
        model = ResNet50(128,256)
    elif a == 'ResNet101':
        model = ResNet101(128, 256)
    elif a == 'SwimTran':
        model = SwimTransformer()
    elif a == 'ViT_16':
        model = ViT_16
    elif a == 'ViT_32':
        model = ViT_32
    elif a == 'SwinTransUNet':
        model = SwinTransUNet
    elif a == 'UNetModern':
        model = Unet_Modern(6,96,'gelu')
    elif a == 'ConvLSTM':
        model = convlstm
    elif a == 'TransMLP':
        model = Unet_Modern(6,96,'relu') #TransMlp()
    elif a == 'ShareMLP':
        model = Trans()
    else:
        model = Unet(6)#Unet(6, 128, 'gelu')
    return model
#
#
#
#
def ModelSize(model):
    param_sum, buffer_sum, all_size = getModelSize(model)
    print(f"Number of Parameters: {param_sum}, Number of Buffers: {buffer_sum}, Size of Model: {all_size:.4f} MB")

if __name__ == "__main__":
    model = model_select('TransMLP')
    param_sum, buffer_sum, all_size = getModelSize(model)
    print(f"Number of Parameters: {param_sum}, Number of Buffers: {buffer_sum}, Size of Model: {all_size:.4f} MB")