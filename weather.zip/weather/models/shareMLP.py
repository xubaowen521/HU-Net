import torch.nn as nn
from functools import partial
import torch
import torch.nn.functional as F

def conv_bn(in_channels, out_channels, kernel_size, stride, padding, groups=1):
    result = nn.Sequential()
    result.add_module('conv', nn.Conv2d(in_channels=in_channels, out_channels=out_channels,
                                                  kernel_size=kernel_size, stride=stride, padding=padding, groups=groups, bias=False))
    result.add_module('bn', nn.BatchNorm2d(num_features=out_channels))
    return result

def conv_bn_relu(in_channels, out_channels, kernel_size, stride, padding, groups=1):
    result = conv_bn(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=stride, padding=padding, groups=groups)
    result.add_module('relu', nn.ReLU())
    return result

class FeedForward(nn.Module):
    def __init__(self, dim, dropout = 0., dense = nn.Linear):
        super().__init__()
        self.net = nn.Sequential(
            dense(dim, dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )

        self._init_weights()

    def _init_weights(self):
        nn.init.xavier_uniform_(self.net[0].weight)
        nn.init.normal_(self.net[0].bias, std=1e-6)

    def forward(self, x):
        return self.net(x)


def window_partition(x, window_size):
    """
    Args:
        x: (B, H, W, C)
        window_size (int): window size

    Returns:
        windows: (num_windows*B, window_size, window_size, C)
    """
    x = x.permute(0, 2, 3, 1)
    B, H, W, C = x.shape
    x = x.view(B, H // window_size, window_size, W // window_size, window_size, C)
    windows = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(-1, window_size, window_size, C)
    return windows


def window_reverse(windows, window_size, H, W):
    """
    Args:
        windows: (num_windows*B, window_size, window_size, C)
        window_size (int): Window size
        H (int): Height of image
        W (int): Width of image

    Returns:
        x: (B, H, W, C)
    """
    B = int(windows.shape[0] / (H * W / window_size / window_size))
    #print(B,H,W,window_size,windows.shape)
    x = windows.view(B, H // window_size, W // window_size, window_size, window_size, -1)
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(B, H, W, -1)
    x = x.permute(0, 3, 1, 2)
    return x


class Patch_share_MLP(nn.Module):
    def __init__(self, in_channels = 6, patch_size = 16, image_size = (128,256),
         dropout = 0.0, reparam_conv_k= (1,3),
                 deploy=False):
        super().__init__()

        assert image_size[0] % patch_size==0 and image_size[1] % patch_size==0, 'The image_size cannot be divided by the patch_size'
        out_channels = in_channels
        self.num_patches = (image_size[0] // patch_size) * (image_size[1] // patch_size)
        self.patch_size = patch_size
        self.h = image_size[0]
        self.w = image_size[1]
        f1 = partial(nn.Conv2d, kernel_size = 1)
        self.f1 = FeedForward(self.patch_size **2, dropout, f1)
        self.deploy = deploy
        self.reparam_conv_k = reparam_conv_k
        if not deploy and reparam_conv_k is not None:
            for k in reparam_conv_k:
                conv_branch = conv_bn(in_channels, out_channels, kernel_size=k, stride=1, padding=k // 2,
                                      groups=in_channels)
                self.__setattr__('repconv{}'.format(k), conv_branch)

    def forward(self, x):
        x = window_partition(x,self.patch_size)
        B_, p_s, p_s, C = x.shape
        partitions = x
        x = x.reshape((-1, p_s **2, 1, 1))
        x = self.f1(x)
        x = x.squeeze(-1).squeeze(-1).view(-1, p_s **2, C)
        #print(x.shape)
        x = x.view(-1, self.patch_size, self.patch_size, C)
        #B = int((x.shape[0] * self.patch_size * self.patch_size) / (self.h * self.w /4))x.view(B, C, int(self.h/2), int(self.w/2))

        fc_out = window_reverse(x, self.patch_size, self.h, self.w)
        #print('cc',fc_out.shape)
        if self.reparam_conv_k is not None and not self.deploy:
            conv_inputs = partitions.permute(0, 3, 1, 2)
            conv_out = 0
            for k in self.reparam_conv_k:
                conv_branch = self.__getattr__('repconv{}'.format(k))
                conv_out += conv_branch(conv_inputs)
            conv_out = window_reverse(conv_out.permute(0, 2, 3, 1), self.patch_size, self.h, self.w)

            fc_out += conv_out
        return fc_out

'''
x = torch.ones((1,6,128,256))
model = Patch_share_MLP()
y = model(x)
print(y.shape)
'''

###downsampling
class PatchMerging(nn.Module):

    def __init__(self, input_resolution, dim):
        super().__init__()
        self.input_resolution = input_resolution
        self.dim = dim
        self.dconv = nn.Conv2d(2 * dim, 2 * dim, kernel_size=3, dilation=2, padding=2)
        self.conv1 = nn.Conv2d(dim, 2 * dim, kernel_size=1, stride=1)
        # in_channels,out_channels,kernel_size,stride = stride,padding = padding,bias = not (use_batchnorm),
        self.conv2 = nn.Conv2d(dim, 2 * dim, kernel_size=1, stride=1)
        self.conv3 = nn.Conv2d(2 * dim, 2 * dim, kernel_size=1, stride=2)
        self.bn1 = nn.BatchNorm2d(dim)
        self.bn2 = nn.BatchNorm2d(2 * dim)
        self.relu = nn.ReLU(inplace=True)
        self.gn1 = nn.GroupNorm(dim // 2, dim)
        self.gn2 = nn.GroupNorm(dim, 2 * dim)
        # self.pool = SoftPool2d(kernel_size=(2, 2), stride=(2, 2))
        self.pool = nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2))
        self.gelu = nn.GELU()

        self._init_weights()

    def _init_weights(self):
        nn.init.xavier_uniform_(self.conv1.weight)
        nn.init.xavier_uniform_(self.conv2.weight)
        nn.init.xavier_uniform_(self.conv3.weight)
        nn.init.xavier_uniform_(self.dconv.weight)
        nn.init.normal_(self.conv1.bias, std=1e-6)
        nn.init.normal_(self.conv2.bias, std=1e-6)
        nn.init.normal_(self.conv3.bias, std=1e-6)
        nn.init.normal_(self.dconv.bias, std=1e-6)
    def forward(self, x):
        B, C, H, W = x.shape
        assert H % 2 == 0 and W % 2 == 0, f"x size ({H}*{W}) are not even."

        short = x
        x = self.gelu(self.bn2(self.conv1(x)))  # 进行1*1卷积操作
        x = self.bn2(self.dconv(x))  # 进行相应的空洞卷积
        x = self.gelu(self.bn2(self.conv3(x)))  # 最后进行1*1卷积，来改变通道数

        short = self.gn1(self.pool(short))  # 进行相应的soft-pool池化操作
        short = self.gelu(self.bn2(self.conv2(short)))

        x = x + short       # B 2*C H/2 W/2

        return x
'''
x = torch.ones((1,6,128,256))
model = PatchMerging((128,256),6)
y = model(x)
print('1',y.shape)
'''
#####share-channel


def fuse_bn(conv_or_fc, bn):
    std = (bn.running_var + bn.eps).sqrt()
    t = bn.weight / std
    t = t.reshape(-1, 1, 1, 1)

    if len(t) == conv_or_fc.weight.size(0):
        return conv_or_fc.weight * t, bn.bias - bn.running_mean * bn.weight / std
    else:
        repeat_times = conv_or_fc.weight.size(0) // len(t)
        repeated = t.repeat_interleave(repeat_times, 0)
        return conv_or_fc.weight * repeated, (bn.bias - bn.running_mean * bn.weight / std).repeat_interleave(
            repeat_times, 0)


class GlobalPerceptron(nn.Module):

    def __init__(self, input_channels, internal_neurons):
        super(GlobalPerceptron, self).__init__()
        self.fc1 = nn.Conv2d(in_channels=input_channels, out_channels=internal_neurons, kernel_size=1, stride=1, bias=True)
        self.fc2 = nn.Conv2d(in_channels=internal_neurons, out_channels=input_channels, kernel_size=1, stride=1, bias=True)
        self.input_channels = input_channels
        self._init_weights()

    def _init_weights(self):
        nn.init.xavier_uniform_(self.fc1.weight)
        nn.init.xavier_uniform_(self.fc2.weight)
        nn.init.normal_(self.fc1.bias, std=1e-6)
        nn.init.normal_(self.fc2.bias, std=1e-6)
    def forward(self, inputs):
        x = F.adaptive_avg_pool2d(inputs, output_size=(1, 1))
        x = self.fc1(x)
        x = F.relu(x, inplace=True)
        x = self.fc2(x)
        x = F.sigmoid(x)
        x = x.view(-1, self.input_channels, 1, 1)
        return x


class RepMLPBlock(nn.Module):

    def __init__(self, in_channels,
                 h, w,
                 reparam_conv_k=(1, 3),
                 globalperceptron_reduce=4,
                 num_sharesets=2,
                 deploy=False):
        super().__init__()

        self.C = in_channels
        self.S = num_sharesets
        self.h, self.w = h, w

        self.deploy = deploy
        self.fc3 = nn.Conv2d(self.h * self.w * num_sharesets, self.h * self.w * num_sharesets, 1, 1, 0, bias=deploy, groups=num_sharesets)
        if deploy:
            self.fc3_bn = nn.Identity()
        else:
            self.fc3_bn = nn.BatchNorm2d(num_sharesets)
        self.gp = GlobalPerceptron(input_channels=in_channels, internal_neurons=in_channels // globalperceptron_reduce)
        self.reparam_conv_k = reparam_conv_k
        if not deploy and reparam_conv_k is not None:
            for k in reparam_conv_k:
                conv_branch = conv_bn(num_sharesets, num_sharesets, kernel_size=k, stride=1, padding=k//2, groups=num_sharesets)
                self.__setattr__('repconv{}'.format(k), conv_branch)
        self._init_weights()

    def _init_weights(self):
        nn.init.xavier_uniform_(self.fc3.weight)

    def partition_affine(self, x):
        fc_inputs = x.reshape(-1, self.S * self.h * self.w, 1, 1)
        out = self.fc3(fc_inputs)
        out = out.reshape(-1, self.S, self.h, self.w)
        out = self.fc3_bn(out)
        return out

    def forward(self, inputs):
        global_vec = self.gp(inputs)
        #print(global_vec.shape)
        origin_shape = inputs.size()
        partitions = inputs

        #   Channel Perceptron
        fc3_out = self.partition_affine(partitions)

        #   Local Perceptron
        if self.reparam_conv_k is not None and not self.deploy:
            conv_inputs = partitions.reshape(-1, self.S, self.h, self.w)
            conv_out = 0
            for k in self.reparam_conv_k:
                conv_branch = self.__getattr__('repconv{}'.format(k))
                conv_out += conv_branch(conv_inputs)
            fc3_out += conv_out

        out = fc3_out.reshape(*origin_shape)
        out = out * global_vec
        return out

    def get_equivalent_fc3(self):
        fc_weight, fc_bias = fuse_bn(self.fc3, self.fc3_bn)
        if self.reparam_conv_k is not None:
            largest_k = max(self.reparam_conv_k)
            largest_branch = self.__getattr__('repconv{}'.format(largest_k))
            total_kernel, total_bias = fuse_bn(largest_branch.conv, largest_branch.bn)
            for k in self.reparam_conv_k:
                if k != largest_k:
                    k_branch = self.__getattr__('repconv{}'.format(k))
                    kernel, bias = fuse_bn(k_branch.conv, k_branch.bn)
                    total_kernel += F.pad(kernel, [(largest_k - k) // 2] * 4)
                    total_bias += bias
            rep_weight, rep_bias = self._convert_conv_to_fc(total_kernel, total_bias)
            final_fc3_weight = rep_weight.reshape_as(fc_weight) + fc_weight
            final_fc3_bias = rep_bias + fc_bias
        else:
            final_fc3_weight = fc_weight
            final_fc3_bias = fc_bias
        return final_fc3_weight, final_fc3_bias

    def local_inject(self):
        self.deploy = True
        #   Locality Injection
        fc3_weight, fc3_bias = self.get_equivalent_fc3()
        #   Remove Local Perceptron
        if self.reparam_conv_k is not None:
            for k in self.reparam_conv_k:
                self.__delattr__('repconv{}'.format(k))
        self.__delattr__('fc3')
        self.__delattr__('fc3_bn')
        self.fc3 = nn.Conv2d(self.S * self.h * self.w, self.S * self.h * self.w, 1, 1, 0, bias=True, groups=self.S)
        self.fc3_bn = nn.Identity()
        self.fc3.weight.data = fc3_weight
        self.fc3.bias.data = fc3_bias

    def _convert_conv_to_fc(self, conv_kernel, conv_bias):
        I = torch.eye(self.h * self.w).repeat(1, self.S).reshape(self.h * self.w, self.S, self.h, self.w).to(
            conv_kernel.device)
        fc_k = F.conv2d(I, conv_kernel, padding=(conv_kernel.size(2) // 2, conv_kernel.size(3) // 2), groups=self.S)
        fc_k = fc_k.reshape(self.h * self.w, self.S * self.h * self.w).t()
        fc_bias = conv_bias.repeat_interleave(self.h * self.w)
        return fc_k, fc_bias


#####
'''
x = torch.ones((1,24,8,16))
model = RepMLPBlock(24,8,16)
model.eval()
y = model(x)
model.local_inject()
new_y = model(x)
#print(y,new_y)  #torch.Size([1, 6, 128, 256])
print((new_y - y).abs().sum())
'''
class PatchShareBasicLayer(nn.Module):
    """ A basic Swin Transformer layer for one stage."""
    def __init__(self,in_channel = 6,
                 input_resolution = (64,128),
                 depth=1, patch_size=16,
                 drop=0.,
                 downsample=PatchMerging):

        super().__init__()
        self.input_resolution = input_resolution
        self.depth = depth

        self.blocks = nn.ModuleList([
            Patch_share_MLP(in_channels = in_channel, patch_size = patch_size, image_size = input_resolution,
         dropout = drop, reparam_conv_k= (1,3),deploy=False)
            for _ in range(depth)])

        # patch merging layer
        if downsample is not None:
            self.downsample = downsample(input_resolution, dim=in_channel)
        else:
            self.downsample = None

    def forward(self, x):
        for blk in self.blocks:
            x = blk(x)
        #if self.downsample is not None:
        #    x = self.downsample(x)

        return x
#x = torch.ones((1,96,64,128))
#model = PatchShareBasicLayer(96,(64,128))
#y = model(x)
#print(y.shape)
class ChannelShareBasicLayer(nn.Module):
    """ A basic Swin Transformer layer for one stage."""
    def __init__(self,in_channel = 96,
                 input_resolution = (16,32),
                 depth=2,
                 drop=0.,
                 num_sharesets = 2):

        super().__init__()
        self.input_resolution = input_resolution
        self.depth = depth

        self.blocks = nn.ModuleList([
            RepMLPBlock(in_channels=in_channel,
                 h= input_resolution[0], w=input_resolution[1],
                 reparam_conv_k=(1, 3),
                 globalperceptron_reduce=4,
                 num_sharesets=num_sharesets,
                 deploy=False)
            for _ in range(depth)])


    def forward(self, x):
        for blk in self.blocks:
            x = blk(x)


        return x


class LocalMLPNet(nn.Module):

    def __init__(self,
                 in_channels=6,
                 patch_size=(16, 8, 4),
                 num_blocks=(2,2,2,2),
                 img_size = (128,256),
                 sharesets_nums=(2,2,2,2),
                 reparam_conv_k=(3,),
                 globalperceptron_reduce=4,
                 deploy=False):
        super().__init__()
        num_stages = len(num_blocks)
        hs = (img_size[0], int(img_size[0]/2), int(img_size[0]/4), int(img_size[0]/8))
        ws = (img_size[1], int(img_size[1]/2), int(img_size[1]/4), int(img_size[1]/8))
        channels = (48, 96, 192, 384)
        #assert num_stages == len(channels)
        assert num_stages == len(hs)
        assert num_stages == len(ws)
        assert num_stages == len(sharesets_nums)

        self.conv_embedding = conv_bn_relu(in_channels, channels[0], kernel_size=1,stride=1,padding=0)

        stages = []
        embeds = []
        for stage_idx in range(num_stages):
            if stage_idx <= 2:
                #print(channels[stage_idx],hs[stage_idx],ws[stage_idx])
                stage_blocks = [PatchShareBasicLayer(in_channel = channels[stage_idx],
                 input_resolution = (hs[stage_idx],ws[stage_idx]),
                 depth=2, patch_size=patch_size[stage_idx],
                 drop=0.3,) for _ in range(num_blocks[stage_idx])]
            else:
                #print(channels[stage_idx])
                stage_blocks = [ChannelShareBasicLayer(in_channel = channels[stage_idx],
                 input_resolution = (hs[stage_idx],ws[stage_idx]),
                 depth=2,
                 drop=0.3,num_sharesets=sharesets_nums[stage_idx]) for _ in range(num_blocks[stage_idx])]
            stages.append(nn.ModuleList(stage_blocks))
            embeds.append(PatchMerging(input_resolution=(hs[stage_idx],ws[stage_idx]),dim=channels[stage_idx]))

        self.stages = nn.ModuleList(stages)
        self.embeds = nn.ModuleList(embeds)



    def forward(self, x):
        x = self.conv_embedding(x)
        MLP_features = []
        #print('123', x.shape)
        for i, stage in enumerate(self.stages):
            for block in stage:
                x = block(x)
            embed = self.embeds[i]
            x = embed(x)
            MLP_features.append(x)
        return MLP_features

    def locality_injection(self):
        for m in self.modules():
            if hasattr(m, 'local_inject'):
                m.local_inject()

class ShareMLP(nn.Module):

    def __init__(self,):
        super().__init__()
        self.encoder = LocalMLPNet()
        channels = (768, 384, 192, 96, 48, )
        self.upsample = []
        #for i in range(len(channels)):
        #    self.upsample.append(nn.ConvTranspose2d(channels[i],channels[i+1] if i <=len(channels)-2 else 6,(4, 4), (2, 2), (1, 1)).to('cuda:1'))
        self.last = nn.Conv2d(channels[0],6,1).to('cuda:1')
        self.linear1 = nn.Linear(8, 128).to('cuda:1')
        self.linear2 = nn.Linear(16, 256).to('cuda:1')


    def forward(self, x):
        x_ = self.encoder(x)
        x = x_[-1]
        #for i in range(len(x_)):
        #    x = self.upsample[i](x)
        #print(x.shape)
        x = self.last(x)
        x = self.linear1(self.linear2(x).transpose(-2,-1)).transpose(-2,-1)
        return x

if __name__ == '__main__':
    x = torch.randn(1, 6, 128, 256).to('cuda:1')
    model = ShareMLP().to('cuda:1')
    out = model(x)
    #for i in out:
    print(out.shape)
    param_size = 0
    for param in model.parameters():
        param_size += param.nelement() * param.element_size()
    print(f'{param_size/1024/1024} M')