import torch
from torch import nn
from models.TransMLPEncoder import TransMlpEncoder
#from MLP import conv_bn_relu


def batchmul2d(input, weights):
    # (batch, in_channel, x,y ), (in_channel, out_channel, x,y) -> (batch, out_channel, x,y)
    return torch.einsum("bixy,ioxy->boxy", input, weights)

class SpectralConv2d(nn.Module):
    """2D Fourier layer. Does FFT, linear transform, and Inverse FFT.
    Implemented in a way to allow multi-gpu training.
    Args:
        in_channels (int): Number of input channels
        out_channels (int): Number of output channels
        modes1 (int): Number of Fourier modes to keep in the first spatial direction
        modes2 (int): Number of Fourier modes to keep in the second spatial direction
    [paper](https://arxiv.org/abs/2010.08895)
    """

    def __init__(self, in_channels: int, out_channels: int, modes1: int, modes2: int):
        super().__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.modes1 = modes1  # Number of Fourier modes to multiply, at most floor(N/2) + 1
        self.modes2 = modes2

        self.scale = 1 / (in_channels * out_channels)
        self.weights1 = nn.Parameter(
            self.scale * torch.rand(in_channels, out_channels, self.modes1, self.modes2, 2, dtype=torch.float32)
        )
        self.weights2 = nn.Parameter(
            self.scale * torch.rand(in_channels, out_channels, self.modes1, self.modes2, 2, dtype=torch.float32)
        )

    def forward(self, x,):
        batchsize = x.shape[0]
        # Compute Fourier coeffcients up to factor of e^(- something constant)
        x_ft = torch.fft.rfft2(x)

        # Multiply relevant Fourier modes
        out_ft = torch.zeros(
            batchsize,
            self.out_channels,
            x.size(-2),
            x.size(-1) // 2 + 1,
            dtype=torch.cfloat,
            device=x.device,
        )
        out_ft[:, :, : self.modes1, : self.modes2] = batchmul2d(
            x_ft[:, :, : self.modes1, : self.modes2], torch.view_as_complex(self.weights1)
        )
        out_ft[:, :, -self.modes1 :, : self.modes2] = batchmul2d(
            x_ft[:, :, -self.modes1 :, : self.modes2], torch.view_as_complex(self.weights2)
        )

        # Return to physical space
        x = torch.fft.irfft2(out_ft, s=(x.size(-2), x.size(-1)))
        return x

class FourierResidualBlock(nn.Module):
    """Fourier Residual Block to be used in modern Unet architectures.

    Args:
        in_channels (int): Number of input channels.
        out_channels (int): Number of output channels.
        modes1 (int): Number of modes in the first dimension.
        modes2 (int): Number of modes in the second dimension.
        activation (str): Activation function to use.
        norm (bool): Whether to use normalization.
        n_groups (int): Number of groups for group normalization.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        modes1: int = 4,
        modes2: int = 4,
    ):
        super().__init__()
        self.activation = nn.GELU()
        self.modes1 = modes1
        self.modes2 = modes2

        self.fourier1 = SpectralConv2d(in_channels, out_channels, modes1=self.modes1, modes2=self.modes2)

        self.norm1 = nn.BatchNorm2d(in_channels)
        self.norm2 = nn.BatchNorm2d(out_channels)

    def forward(self, x: torch.Tensor):
        # using pre-norms
        h = self.activation(self.norm1(x))
        out = self.fourier1(h)
        out = self.activation(self.norm2(out))
        return out

class FourierUpBlock(nn.Module):
    """Up block that combines [`FourierResidualBlock`][pdearena.modules.twod_unet.FourierResidualBlock] and [`AttentionBlock`][pdearena.modules.twod_unet.AttentionBlock].

    These are used in the second half of U-Net at each resolution.

    Note:
        We currently don't recommend using this block.
    """

    def __init__(
        self,
        out_channels: int,
        modes1: int = 4,
        modes2: int = 4,
    ):
        super().__init__()
        # The input has `in_channels + out_channels` because we concatenate the output of the same resolution
        # from the first half of the U-Net
        in_channels = 2 * out_channels
        self.res = FourierResidualBlock(
            in_channels ,
            out_channels,
            modes1=modes1,
            modes2=modes2
        )

    def forward(self, x: torch.Tensor):
        x = self.res(x)
        return x


class TransMlp(nn.Module):
    def __init__(self,device='cuda:1', modes1 = 3,modes2 = 3,drop = 0.3):
        super().__init__()
        channels = (48, 96, 192, 384)
        out_channels = (6, 48, 96, 192)

        num_stages = len(channels)
        self.encoder = TransMlpEncoder(device)
        ###decoder
        self.midden = FourierUpBlock(channels[-1],modes1=modes1,modes2=modes2)#nn.Conv2d(2*channels[-1],channels[-1],1)
        self.upsample = nn.UpsamplingBilinear2d(scale_factor=2)
        self.up = nn.ModuleList()
        for i in reversed(range(num_stages)):
            # `n_blocks` at the same resolution
            #print(channels[i-1],out_channels[i])
            self.up.append(nn.Sequential(FourierUpBlock(
                    channels[i],
                    modes1= modes1,
                    modes2= modes2),
                nn.Conv2d(channels[i], out_channels[i], kernel_size=1),nn.Dropout(drop),
                nn.Identity() if i==0 else nn.UpsamplingBilinear2d(scale_factor=2)))

#conv_bn_relu(2*channels[i],channels[i],kernel_size=1,stride=1,padding=0) if i != 0 else
    def forward(self, x):
        features, x_ = self.encoder(x)
        last_encoder = features[-1]
        out = self.midden(last_encoder)      #(b,384,16,32)
        out = self.upsample(out)
        h = features[::-1] + [x_]
        for i,m in enumerate(self.up):
            s = h[i+1]
            #print('a',s.shape)
            out = torch.cat((out, s), dim=1)
            #print('b',out.shape)
            out = m(out)
            #print('c', out.shape)

        return out



if __name__ == '__main__':
    x = torch.randn(1, 6, 128, 256)
    model = TransMlp()
    out = model(x)
    print(out.shape)
    param_size = 0
    for param in model.parameters():
        param_size += param.nelement() * param.element_size()
    print(f'{param_size/1024/1024} M')