import xarray as xr
import numpy as np
import pickle
from pathlib import Path
import time

def dataset_to_seq2seq(raw_data):
    tmpdata = raw_data
    print('Mean:{}, Max{}, Min{}, Std{}'.format(tmpdata.mean().values, tmpdata.max().values, tmpdata.min().values, tmpdata.std().values))
    horizon = 10
    input_len = 10
    step_size = 1
    L = tmpdata.shape[0]
    print(L)
    dataset_x=[]
    dataset_y=[]
    for i in range(input_len):
        dataset_x.append(tmpdata[i:L-horizon-input_len+i])
    for j in range(horizon):
        dataset_y.append(tmpdata[j+input_len:L-horizon+j])
    dataset_x = np.stack(dataset_x,axis=1)
    dataset_y = np.stack(dataset_y,axis=1)
    print('abc',dataset_x.shape)
    num_samples, input_len = dataset_x.shape[0], dataset_x.shape[1]
    #dataset_x = dataset_x.squeeze(-2)#.reshape(num_samples, input_len, -1)
    #dataset_y = dataset_y.squeeze(-2)#.reshape(num_samples, horizon, -1)
    idx = [i*step_size for i in range(num_samples//step_size)]
    dataset_x = dataset_x[idx]
    dataset_y = dataset_y[idx]
    #seq2seq_data = dataset_x
    #num_samples = seq2seq_data.shape[0]
    #print('123',num_samples)
    #num_test = round(num_samples * 0.2)
    #num_train = round(num_samples * 0.7)
    #num_val = num_samples - num_test - num_train
    #print('Number of training samples: {}, validation samples:{}, test samples:{}'.format(num_train, num_val, num_test))
#
    #train_x = seq2seq_data[:num_train]
    ##train_y = seq2seq_label[:num_train]
#
    #val_x = seq2seq_data[num_train:num_train + num_val]
    ##val_y = seq2seq_label[num_train:num_train + num_val]
#
    #test_x = seq2seq_data[num_train + num_val:]
    ##test_y = seq2seq_label[num_train + num_val:]
    #datasets = [[train_x], [val_x], [test_x]]   #, train_y, val_y, test_y
    #subsets = ['trn_x', 'val_x', 'test_x']
    #path = '/home/xbw/WeatherBeach/10m_u_component_of_wind'
    #path_ = Path(path)
    #path_.mkdir(exist_ok=True, parents=True)
#
    #for i, subset in enumerate(subsets):
    #    with open(path + '/{}.pkl'.format(subset), "wb") as f:
    #        save_data = {'x': datasets[i][0]}   #,
    #                     #'y': datasets[i][1]
    #        pickle.dump(save_data, f, protocol=4)
    #        del datasets[i][0]
    return dataset_x, dataset_y
t1 = time.time()
data = xr.open_mfdataset('/home/xbw/2m_temperature/*.nc', combine='by_coords')
#time = data.time.values
raw_data = data.t2m
print('546',raw_data.shape[0])
if len(raw_data.shape) == 4:  # when there are different level, we choose the 13-th level which is sea level
    raw_data = raw_data[:, -1, ...]
lons = raw_data.lon
lats = raw_data.lat
#print(raw_data)
##from lianxi import *
##data = raw_data[7]
##fig = plt.figure(figsize=(6, 6))
### 调入参数，画图
##ax1 = fig.add_subplot(1, 1, 1, projection=proj)
##map_plot(fig, ax1,  lats, lons,data, True, True, 'T2 in April 2022')  # 绘制大地图
##plt.savefig('t.jpg')

seq2seq_data, seq2seq_label= dataset_to_seq2seq(raw_data)  #

num_samples = seq2seq_data.shape[0]
num_test = round(num_samples * 0.2)
num_train = round(num_samples * 0.7)
num_val = num_samples - num_test - num_train
print('Number of training samples: {}, validation samples:{}, test samples:{}'.format(num_train, num_val, num_test))
print(seq2seq_data.shape)
train_x = seq2seq_data[:num_train]
train_y = seq2seq_label[:num_train]

val_x = seq2seq_data[num_train:num_train + num_val]
val_y = seq2seq_label[num_train:num_train + num_val]

test_x = seq2seq_data[num_train + num_val:]
test_y = seq2seq_label[num_train + num_val:]
datasets = [[train_x, train_y], [val_x, val_y], [test_x, test_y]]
subsets = ['trn', 'val', 'test']
path = '/home/xbw/WeatherBeach/2m_temperature'
path_ = Path(path)
path_.mkdir(exist_ok=True, parents=True)

for i, subset in enumerate(subsets):
    with open(path + '/{}.pkl'.format(subset), "wb") as f:
        save_data = {'x': datasets[i][0],
                     'y': datasets[i][1]}
        pickle.dump(save_data, f, protocol=4)

with open(path + '/{}.pkl'.format('position_info'), "wb") as f:
    save_data = {'lon': lons,
                 'lat': lats}
    pickle.dump(save_data, f, protocol=4)
t2 = time.time()
print('total time :', t2-t1)