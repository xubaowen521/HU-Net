import argparse
import pickle
import torch.utils.data
from data_util import dataset_to_seq2seq
import xarray as xr
'''
class Dataset(torch.utils.data.Dataset):
    def __init__(self, input_folder, input_preprocessed, args):
        self.input_preprocessed = input_preprocessed
        self.args = args

        if args.use_preprocessed:
            with open(input_preprocessed, 'rb') as f:
                self.data = pickle.load(f)
        else:
            data = xr.open_mfdataset(f"{input_folder}/**/*.nc", combine='by_coords')
            self.raw_data = data.t2m
            self.data_reader = dataset_to_seq2seq

    def forward(self,):
        if self.args.use_preprocessed:
            return self.data
        else:

            return self.data_reader(self.raw_data)
'''
class WDataset(torch.utils.data.Dataset):
    def __init__(self, input_folder):
        data = xr.open_mfdataset(f"{input_folder}/**/*.nc", combine='by_coords')
        self.raw_data = data.t2m
        self.data_reader = dataset_to_seq2seq

    def forward(self,):

        return self.data_reader(self.raw_data)
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--use_preprocessed", type=bool, default=False)
    args = parser.parse_args()
    WDataset('/home/xbw/WeatherBeach/2m_temperature')