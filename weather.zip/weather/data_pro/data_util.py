from multiprocessing import Pool
import numpy as np
import pickle
from pathlib import Path
import time

def dataset_to_seq2seq(raw_data):

    tmpdata = raw_data
    print('Mean:{}, Max{}, Min{}, Std{}'.format(tmpdata.mean().values, tmpdata.max().values, tmpdata.min().values, tmpdata.std().values))
    horizon = 10
    input_len = 10
    step_size = 1
    L = tmpdata.shape[0]
    print(L)
    dataset_x=[]
    dataset_y=[]
    for i in range(input_len):
        dataset_x.append(tmpdata[i:L-horizon-input_len+i])
    for j in range(horizon):
        dataset_y.append(tmpdata[j+input_len:L-horizon+j])
    dataset_x = np.stack(dataset_x,axis=1)
    dataset_y = np.stack(dataset_y,axis=1)
    print('abc',dataset_x.shape)
    num_samples, input_len = dataset_x.shape[0], dataset_x.shape[1]
    #dataset_x = dataset_x.squeeze(-2)#.reshape(num_samples, input_len, -1)
    #dataset_y = dataset_y.squeeze(-2)#.reshape(num_samples, horizon, -1)
    idx = [i*step_size for i in range(num_samples//step_size)]
    seq2seq_data = dataset_x[idx]
    seq2seq_label = dataset_y[idx]
    num_samples = seq2seq_data.shape[0]
    num_test = round(num_samples * 0.2)
    num_train = round(num_samples * 0.7)
    num_val = num_samples - num_test - num_train
    print('Number of training samples: {}, validation samples:{}, test samples:{}'.format(num_train, num_val, num_test))
    print(seq2seq_data.shape)
    train_x = seq2seq_data[:num_train]
    train_y = seq2seq_label[:num_train]

    val_x = seq2seq_data[num_train:num_train + num_val]
    val_y = seq2seq_label[num_train:num_train + num_val]

    test_x = seq2seq_data[num_train + num_val:]
    test_y = seq2seq_label[num_train + num_val:]
    datasets = [[train_x, train_y], [val_x, val_y], [test_x, test_y]]
    subsets = ['trn', 'val', 'test']
    path = '/home/xbw/total_precipitation'
    path_ = Path(path)
    path_.mkdir(exist_ok=True, parents=True)

    for i, subset in enumerate(subsets):
        with open(path + '/{}.pkl'.format(subset), "wb") as f:
            save_data = {'x': datasets[i][0],
                         'y': datasets[i][1]}
            pickle.dump(save_data, f, protocol=4)

    return dataset_x, dataset_y