import torch
import numpy as np
import argparse
import time
from tensorboardX import SummaryWriter
from engine import *
import os
import shutil
import random
from dataset import build_loader
import warnings
warnings.filterwarnings('ignore')

parser = argparse.ArgumentParser()
###data
parser.add_argument('--dataset_dir', type=str, default='/home/xbw/total_precipitation', help='data path')
parser.add_argument('--test', type=bool, default=False, help='whether to test')
parser.add_argument('--batch_size', type=int, default=16, help='batch size')
###model
parser.add_argument('--spatial_highth', type=int, default=128, help='inputs dimension')
parser.add_argument('--spatial_width', type=int, default=256, help='number of nodes')
parser.add_argument('--dropout', type=float, default=0.3, help='dropout rate')
parser.add_argument('--seq_length', type=int, default=6, help='inputs dimension')
####training
parser.add_argument('--embed_dim', type=int, default=32, help='node embedding dim')
parser.add_argument('--learning_rate', type=float, default=0.0001, help='learning rate')
parser.add_argument('--weight_decay', type=float, default=0.0001, help='weight decay rate')
parser.add_argument('--epochs', type=int, default=50, help='')
parser.add_argument('--print_every', type=int, default=1000, help='')
parser.add_argument('--force', type=str, default=False, help="remove params dir", required=False)
parser.add_argument('--save', type=str, default='/home/xbw/weather_beach/tp',
                    help='save path')
parser.add_argument('--expid', type=int, default=1, help='experiment id')
parser.add_argument('--model', type=str, default='HUNet', help='model type')
parser.add_argument('--decay', type=float, default=0.92, help='decay rate of learning rate ')

args = parser.parse_args()

seed = 2023
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.cuda.manual_seed_all(seed)
writer = SummaryWriter()


def main():
    device = 'cuda:1' if torch.cuda.is_available() else 'cpu'
    dataset, dataloader = build_loader(args)
    Scaler = dataset['scaler']

    engines = trainer(device, args.seq_length, args.spatial_highth, args.spatial_width, Scaler,
                        args.learning_rate,  args.decay, args.weight_decay)

    # check parameters file
    params_path = args.save + "/" + args.model
    if os.path.exists(params_path) and not args.force:
        raise SystemExit("Params folder exists! Select a new params path please!")
    else:
        if os.path.exists(params_path):
            shutil.rmtree(params_path)
        os.makedirs(params_path)
        print('Create params directory %s' % (params_path))

    print("start training...", flush=True)
    his_loss = []
    val_time = []
    train_time = []
    for i in range(1, args.epochs + 1):
        train_loss = []
        train_mae = []
        train_mape = []
        train_rmse = []
        t1 = time.time()
        for iter, (x, y) in enumerate(dataloader['train_loader']):
            trainx = torch.Tensor(x).to(device)
            trainy = torch.Tensor(y).to(device)
            metrics = engines.train(trainx, trainy)
            train_loss.append(metrics[0])
            train_mae.append(metrics[1])
            train_mape.append(metrics[2])
            train_rmse.append(metrics[3])
            '''
            if iter % args.print_every == 0:
                log = 'Iter: {:03d}, Train Loss: {:.4f}, Train MAE: {:.4f},Train MAPE: {:.4f}, Train RMSE: {:.4f}'
                print(log.format(iter, train_loss[-1], train_mae[-1],train_mape[-1], train_rmse[-1]),flush=True)
            '''
        t2 = time.time()
        train_time.append(t2 - t1)
        # validation
        valid_loss = []
        valid_mae = []
        valid_mape = []
        valid_rmse = []

        s1 = time.time()

        for iter, (x, y) in enumerate(dataloader['val_loader']):
            testx = torch.Tensor(x).to(device)
            testy = torch.Tensor(y).to(device)
            metrics = engines.eval(testx, testy)
            valid_loss.append(metrics[0])
            valid_mae.append(metrics[1])
            valid_mape.append(metrics[2])
            valid_rmse.append(metrics[3])
        s2 = time.time()
        log = 'Epoch: {:03d}, Inference Time: {:.4f} secs'
        print(log.format(i, (s2 - s1)))
        val_time.append(s2 - s1)
        mtrain_loss = np.mean(train_loss)
        mtrain_mae = np.mean(train_mae)
        mtrain_mape = np.mean(train_mape)
        mtrain_rmse = np.mean(train_rmse)

        mvalid_loss = np.mean(valid_loss)
        mvalid_mae = np.mean(valid_mae)
        mvalid_mape = np.mean(valid_mape)
        mvalid_rmse = np.mean(valid_rmse)
        his_loss.append(mvalid_loss*10000)
        writer.add_scalars('Loss', {'train_loss': mtrain_loss, 'val_loss': mvalid_loss}, i)

        log = 'Epoch: {:03d}, Train Loss: {:.4f}, Train MAE: {:.5f}, Train MAPE: {:.4f}, Train RMSE: {:.5f}, Valid Loss: {:.4f}, Valid MAE: {:.4f}, Valid MAPE: {:.4f}, Valid RMSE: {:.4f}, Training Time: {:.4f}/epoch'
        print(log.format(i, mtrain_loss, mtrain_mae, mtrain_mape, mtrain_rmse, mvalid_loss*10000, mvalid_mae*10000, mvalid_mape,
                         mvalid_rmse*10000, (t2 - t1)), flush=True)
        torch.save(engines.model.state_dict(),
                   params_path + "/" + args.model + "_epoch_" + str(i) + "_" + str(round(mvalid_loss*10000, 2)) + ".pth")
    writer.close()
    print("Average Training Time: {:.4f} secs/epoch".format(np.mean(train_time)))
    print("Average Inference Time: {:.4f} secs".format(np.mean(val_time)))
    bestid = np.argmin(his_loss)
    path_old = params_path + "/" + args.model + "_epoch_" + str(bestid + 1) + "_" + str(round(his_loss[bestid], 2)) + ".pth"
    path_raw = params_path + "/" + args.model + "_epoch_" + str('best') + ".pth"
    os.rename(os.path.join(path_old), os.path.join(path_raw))

if __name__ == "__main__":
    t1 = time.time()
    main()
    t2 = time.time()
    print("Total time spent: {:.4f}".format(t2 - t1))