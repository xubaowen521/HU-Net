import time
import os
import datetime
import numpy as np
import shutil
import torch.backends.cudnn as cudnn
import torch.distributed as dist
from dataset import build_loader
from train.lr_scheduler import build_scheduler
from tools import *
from train.optimizer import build_optimizer
#from Net import Model
from metric import *
from params import get_args
from torchvision import models
import torch.nn as nn

config = get_args()

params_path= './output/T2m/'

class ResNet(nn.Module):
    def __init__(self,high,width):
        super(ResNet, self).__init__()
        net = models.resnet50(pretrained = False)
        net.conv1 = nn.Conv2d(1, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False)
        self.net = nn.Sequential(*list(net.children())[:-3])
        self.high = nn.Linear(8, high)
        self.width = nn.Linear(16, width)
        self.last_conv_1 = nn.Conv2d(1024, 512, kernel_size=1)
        self.last_conv_2 = nn.Conv2d(512, 1, kernel_size=1)

    def forward(self,x):
        x = self.net(x)
        x = self.width(x).transpose(-2,-1)
        x = self.high(x).transpose(-2,-1)
        x = self.last_conv_1(x)
        x = self.last_conv_2(x)
        return  x

if os.path.exists(params_path):
    raise SystemExit("Params folder exists! Select a new params path please!")
else:
    if os.path.exists(params_path):
        shutil.rmtree(params_path)
    os.makedirs(params_path)
    print('Create params directory %s' % (params_path))

def main(config):
    dataset, data_loader_train, data_loader_val = build_loader(config)
    Scaler = dataset['scaler']
    lat = np.array(dataset['lat'])
    in_channels = len(config.variables)
    #model = Model(in_channels, config.channels_list, config.num_repeat)
    model = ResNet(128,256)
    optimizer = build_optimizer(config, model)
    model.cuda()

    if torch.cuda.device_count() > 1:
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[config.local_rank],
                                                          broadcast_buffers=False)
        model_without_ddp = model.module
    else:
        model_without_ddp = model

    print("Pretrain")
    param_sum, buffer_sum, all_size = getModelSize(model_without_ddp)
    print(f"Number of Parameters: {param_sum}, Number of Buffers: {buffer_sum}, Size of Model: {all_size:.4f} MB")
    lr_scheduler = build_scheduler(config, optimizer, len(data_loader_train))

    loss_scaler = torch.cuda.amp.GradScaler(enabled=True)
    start_time = time.time()
    criterion = [lat_weighted_mse, lat_weighted_rmse, lat_weighted_acc]
    loss_fn = torch.nn.MSELoss()
    for epoch in range(config.epochs):
        data_loader_train.sampler.set_epoch(epoch)

        train_one_epoch(config, model, loss_fn, data_loader_train, optimizer, epoch, loss_scaler, lr_scheduler)
        if epoch >= 0:
            train_loss, train_w_rmse, w_acc = validate(config, data_loader_train, model, criterion, Scaler, lat)
            val_loss, val_w_rmse, w_acc = validate(config, data_loader_val, model, criterion, Scaler ,lat)
            print(
                f"Epoch {epoch} | Train loss: {train_loss:.6f}, Train w_rmse: {train_w_rmse:.6f}, Val loss: {val_loss:.6f}, Val w_rmse: {val_w_rmse:.6f}")
            save_model(model, params_path + "/" + "_epoch_" + str(epoch) + "_" + str(val_w_rmse) + ".pth")
    total_time = time.time() - start_time
    print(f'Total training time: {total_time}')


def train_one_epoch(config, model, criterion, data_loader, optimizer, epoch, loss_scaler, lr_scheduler):
    model.train()
    optimizer.zero_grad()
    num_steps = len(data_loader)
    start = time.time()
    for idx, (samples, targets) in enumerate(data_loader):
        x = samples.cuda(non_blocking=True)
        y = targets.cuda(non_blocking=True)
        with torch.cuda.amp.autocast():
            out = model(x)
            loss = criterion(out, y)   #, args.variables, lat
        loss_scaler.scale(loss).backward()
        loss_scaler.step(optimizer)
        loss_scaler.update()
        optimizer.zero_grad()
        lr_scheduler.step_update(epoch * num_steps + idx)
        torch.cuda.synchronize()
    epoch_time = time.time() - start
    print(f'Time of training round: {epoch_time}')


@torch.no_grad()
def validate(config, data_loader, model, criterion, transform, lat):
    model.eval()
    losses = []
    w_rmse = []
    w_acc = []

    for idx, (images, target) in enumerate(data_loader):
        x = images.cuda(non_blocking=True)
        y = target.cuda(non_blocking=True)
        # compute output
        out = model(x)
        for i in range(len(config.variables)):
            y[:, i, :, :] = transform[i].inverse_transform(y[:, i, :, :])
            out[:, i, :, :] = transform[i].inverse_transform(out[:, i, :, :])

        loss = criterion[0](out, y, config.variables, lat)
        losses.append(loss.item())
        w_rmse.append(criterion[1](out, y, config.variables, lat))
        # w_acc.append(criterion[2](out, y, transform, vars, lat))
    loss = np.mean(losses)
    w_rmse = np.mean(w_rmse)
    w_acc = None  # np.mean(w_acc)

    return loss, w_rmse, w_acc

import os
os.environ["CUDA_VISIBLE_DEVICES"]="0,1"
if __name__ == '__main__':
    #if 'RANK' in os.environ and 'WORLD_SIZE' in os.environ:
    rank = 0#int(os.environ["RANK"])
    world_size = 1#int(os.environ['WORLD_SIZE'])
    os.environ['MASTER_ADDR'] = 'localhost'
    os.environ['MASTER_PORT'] = '5678'
    torch.cuda.set_device(config.local_rank)
    torch.distributed.init_process_group(backend='nccl', init_method='env://', world_size=world_size, rank=rank)
    torch.distributed.barrier()
    seed = config.seed + dist.get_rank()
    torch.manual_seed(seed)
    np.random.seed(seed)
    cudnn.benchmark = True
    main(config)
